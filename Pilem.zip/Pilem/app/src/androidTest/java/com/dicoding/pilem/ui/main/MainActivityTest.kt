package com.dicoding.pilem.ui.main

import androidx.fragment.app.testing.FragmentScenario
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.testing.TestNavHostController
import androidx.recyclerview.widget.RecyclerView
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.dicoding.pilem.R
import com.dicoding.pilem.data.DataDummy
import com.dicoding.pilem.ui.home.HomeFragment
import org.hamcrest.CoreMatchers.equalTo
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest{
    private lateinit var navController : NavController
    private val dummy = DataDummy.generateDummyMovie()
    private lateinit var homeScenario : FragmentScenario<HomeFragment>

    @Before
    fun init(){
        homeScenario = launchFragmentInContainer(themeResId = R.style.Theme_Pilem)
        navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        homeScenario.onFragment{fragment ->
            navController.setGraph(R.navigation.nav_graph)
            Navigation.setViewNavController(fragment.requireView(), navController)
        }
    }

    @Test
    fun popularMovieAndNavigation(){
        val popularDummy = dummy.filter { filmData -> filmData.isPopular }

        onView(withId(R.id.recyclerview_popular_movie)).check(matches(isDisplayed()))
        onView(withId(R.id.recyclerview_popular_movie)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(popularDummy.size))


        onView(withId(R.id.recyclerview_popular_movie)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        assertThat(navController.currentDestination?.id, equalTo(R.id.detailFragment))

    }

    @Test
    fun movieAndNavigation(){
        val movieDummy = dummy.filter { filmData -> !filmData.isPopular }

        onView(withId(R.id.recyclerview_movie)).check(matches(isDisplayed()))
        onView(withId(R.id.recyclerview_movie)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(movieDummy.size))

        onView(withId(R.id.recyclerview_movie)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        assertThat(navController.currentDestination?.id, equalTo(R.id.detailFragment))
    }


    @Test
    fun popularTvShowAndNavigation(){
        val popularDummy = dummy.filter { filmData -> filmData.isPopular }

        onView(withText("TV Show")).perform(click())

        onView(withId(R.id.recyclerview_popular_tvShow)).check(matches(isDisplayed()))
        onView(withId(R.id.recyclerview_popular_tvShow)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(popularDummy.size))


        onView(withId(R.id.recyclerview_popular_tvShow)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        assertThat(navController.currentDestination?.id, equalTo(R.id.detailFragment))

    }

    @Test
    fun tvShowAndNavigation(){
        val movieDummy = dummy.filter { filmData -> !filmData.isPopular }

        onView(withText("TV Show")).perform(click())
        onView(withId(R.id.recyclerview_tvshow)).check(matches(isDisplayed()))
        onView(withId(R.id.recyclerview_tvshow)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(movieDummy.size))

        onView(withId(R.id.recyclerview_tvshow)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        assertThat(navController.currentDestination?.id, equalTo(R.id.detailFragment))

    }
}